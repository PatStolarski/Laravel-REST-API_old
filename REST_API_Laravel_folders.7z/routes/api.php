<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\MainController;


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('127.0.0.1'/'Stolarski'/'310807'/'people', [MainController::class, 'index']);
Route::post('127.0.0.1'/'Stolarski'/'310807'/'people', [MainController::class, 'store']);
Route::get('127.0.0.1'/'Stolarski'/'310807'/'people/{id}', [MainController::class, 'show']);
Route::put('127.0.0.1'/'Stolarski'/'310807'/'people/{id}/edit', [MainController::class, 'update']);
Route::delete('127.0.0.1'/'Stolarski'/'310807'/'people/{id}/delete', [MainController::class, 'destroy']);
<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MainController extends Controller
{
    

    public function index()
    {
        $people = People::all();

        return response()->json([
            'status' => 200,
            'people' => $people
        ],200);
    }

    public function show($id)
    {
        $people = People::findOrfail($id);

        return new PeopleResource($people);
    }

    public function store(PeopleRequest $request)
    {

            $people = new People;
            $people->fill($request->validated())->save();

            return new PeopleResource($People);


    }

    public function update(PeopleRequest $request, $id)
    {

           $people = People::find($id);
           $people->fill($request->validated())->save();

           return new PeopleResource($people);

    }

    public function destroy($id)
    {
        $people = People::find($id);

        $people->delete();
    }
}
